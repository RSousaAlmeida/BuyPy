"""
This module defines functions and classes related to DB access.
"""

from hashlib import sha256 as default_hashalgo
from mysql.connector import connect, Error as MySQLError
# import os
from typing import Optional, Dict


def connect_db():
        config=configpar



def login(username: str, passwd: str) -> Optional[dict]:
    hash_obj = default_hashalgo()
    hash_obj.update(passwd.encode())
    hash_passwd = hash_obj.hexdigest()
    
    try:
        with connect(**DB_CONN_PARAMS) as connection:
            with connection.cursor() as cursor:
                cursor.callproc('AuthenticateOperator', [username, hash_passwd])
                results = next(cursor.stored_results())
                user_info = results.fetchall()
                if len(user_info) != 1:
                    return None
                user_row = user_info[0]
                return dict(zip(results.column_names, user_row))
    except MySQLError as e:
        print(f"Database error: {e}")
        return None
