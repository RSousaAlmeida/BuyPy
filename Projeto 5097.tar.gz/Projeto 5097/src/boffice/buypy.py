"""

BuyPy

"""

import configparser
import mysql.connector
from mysql.connector import Error
import sys
from subprocess import run

CONFIG_PATH = '/home/formando/Desktop/Projeto 5097/src/config.ini'

def carregar_configuracao(caminho_config=CONFIG_PATH):
    config = configparser.ConfigParser()
    config.read(caminho_config)
    return config

def conectar_bd(config):
    try:
        conexao = mysql.connector.connect(
            host=config['DATABASE']['host'],
            user=config['DATABASE']['user'],
            password=config['DATABASE']['password'],
            database=config['DATABASE']['database']
        )
        return conexao
    except Error as e:
        print(f"Erro ao conectar ao banco de dados: {e}")
        return None

def validar_credenciais(conexao, id, password):
    try:
        cursor = conexao.cursor(dictionary=True)
        sql = "SELECT * FROM Operator WHERE id=%s AND password=%s"
        cursor.execute(sql, (id, password))
        return cursor.fetchone()
    except Error as e:
        print(f"Erro ao validar credenciais: {e}")
        return None

def buscar_utilizador(conexao, campo, valor):
    """
    Busca um utilizador pelo campo especificado na base de dados e exibe seus dados.
    """
    try:
        cursor = conexao.cursor(dictionary=True)
        sql = f"SELECT * FROM Client WHERE {campo}=%s"
        cursor.execute(sql, (valor,))
        user_data = cursor.fetchone()

        if user_data:
            print("Dados do utilizador:")
            print(f"ID: {user_data['id']}")
            print(f"Nome: {user_data['firstname']} {user_data['surname']}")
            print(f"Email: {user_data['email']}")
            print(f"Endereço: {user_data['address']}, {user_data['zip_code']}, {user_data['city']}, {user_data['country']}")
            print(f"Telefone: {user_data['phone_number']}")
            print(f"Data de Nascimento: {user_data['birthdate']}")
            print(f"Último Login: {user_data['last_login']}")
            print(f"Status: {user_data['is_active']}")
        else:
            print("Utilizador não encontrado.")
    except Error as e:
        print(f"Erro ao buscar utilizador por {campo}: {e}")

def login():
    """
    Asks for user login info and then tries to authenticate the user in 
    the DB.
    Stores user data in the local config file 'config.ini' if login is successful.
    """
    id = input("Digite o id de Operador: ")
    password = input("Digite a password: ")

    config = carregar_configuracao(CONFIG_PATH)
    conexao = conectar_bd(config)

    if conexao:
        resultado = validar_credenciais(conexao, id, password)
        conexao.close()
        if resultado:
            print("Login bem-sucedido!")
            config['User'] = {
                'firstname': resultado['firstname'],
                'surname': resultado['surname'],
                'email': resultado['email']
            }
            with open(CONFIG_PATH, 'w') as configfile:
                config.write(configfile)
            return resultado
        else:
            print("Nome de usuário ou senha inválidos.")
            return None
    else:
        print("Não foi possível conectar ao banco de dados.")
        return None

def cls():
    if sys.platform in ('linux', 'darwin', 'freebsd'):
        run(['clear'])
    elif sys.platform == 'win32':
        run(['cls'], shell=True)

def menu_utilizador(conexao):
    """
    Menu de opções do utilizador para pesquisar por ID ou username.
    """
    while True:
        print("\nMenu UTILIZADOR")
        print("1 - Pesquisar por ID de utilizador")
        print("2 - Pesquisar por email de utilizador")
        print("0 - Voltar ao menu anterior")

        option = input(">> ")

        if option == '1':
            search_id = input("Digite o ID do utilizador: ")
            buscar_utilizador(conexao, 'id', search_id)
        elif option == '2':
            email = input("Digite o email do utilizador: ")
            buscar_utilizador(conexao, 'email', email)
        elif option == '0':
            return
        else:
            print("Opção inválida")

def main():
    user_info = login()

    if not user_info:
        print("Falha na autenticação. O programa será encerrado.")
        return

    # Conectar ao banco de dados
    config = carregar_configuracao(CONFIG_PATH)
    conexao = conectar_bd(config)

    if not conexao:
        print("Não foi possível conectar ao banco de dados.")
        return

    while True:
        cls()
        print(f"\nBem vindo {user_info['firstname']}\n")
        print("U - Menu 'Utilizador'")
        print("S - Sair do BackOffice")
        print("L - Logout do BackOffice")

        option = input(">> ")

        if option.lower() == 'u':
            menu_utilizador(conexao)  # Passando a conexão como parâmetro
        elif option.lower() == 's':
            print("O BackOffice vai terminar")
            sys.exit(0)
        elif option.lower() == 'l':
            print("Logout bem-sucedido")
            user_info = login()
            if not user_info:
                print("Falha na autenticação. O programa será encerrado.")
                return
        else:
            print(f"Opção <{option}> inválida ")

if __name__ == '__main__':
    main()