# select * from BuyPy.Order
# 

DROP PROCEDURE IF EXISTS ProductByType;
DROP PROCEDURE IF EXISTS OrdersByClientAndYear;
DROP PROCEDURE IF EXISTS CalculateOrderTotal;

DELIMITER //

CREATE PROCEDURE ProductByType (
    IN p_TipoProduto VARCHAR(50)
)
BEGIN
    IF p_TipoProduto IS NULL THEN      
        SELECT 
            Product.id,
            Product.price,
            Product.score,
            Recommendation.reason,
            Product.is_active,
            Product.product_image,
            CASE
                WHEN Book.product_id IS NOT NULL THEN 'Book'
                WHEN Electronic.product_id IS NOT NULL THEN 'Electronic'
            END AS TipoProduto
        FROM 
            Product
        LEFT JOIN 
            Book ON Product.id = Book.product_id
        LEFT JOIN 
            Electronic ON Product.id = Electronic.product_id
        LEFT JOIN 
            Recommendation ON Product.id = Recommendation.product_id;
    ELSE
       SELECT 
            Product.id,
            Product.price,
            Product.score,
            Recommendation.reason,
            Product.is_active,
            Product.product_image,
            CASE
                WHEN Book.product_id IS NOT NULL THEN 'Book'
                WHEN Electronic.product_id IS NOT NULL THEN 'Electronic'
            END AS TipoProduto
        FROM 
            Product
        LEFT JOIN 
            Book ON Product.id = Book.product_id
        LEFT JOIN 
            Electronic ON Product.id = Electronic.product_id
        LEFT JOIN 
            Recommendation ON Product.id = Recommendation.product_id
        WHERE 
            (Electronic.product_id IS NOT NULL AND p_TipoProduto = 'Electronic')
            OR (Book.product_id IS NOT NULL AND p_TipoProduto = 'Book');
    END IF;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE OrdersByClientAndYear(
    IN client_id_pm INT,
    IN year_pm INT
)
BEGIN
    SELECT 
        o.id AS order_id, 
        o.date_time AS order_date,
        o.delivery_method,
        o.status,
        oi.product_id,
        oi.quantity,
        oi.price,
        oi.vat_amount
    FROM 
        `Order` o
    INNER JOIN 
        Ordered_Item oi ON o.id = oi.order_id
    WHERE 
        YEAR(o.date_time) = year_pm
        AND o.client_id = client_id_pm;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE CalculateOrderTotal(
    IN order_id_pm INT
)
BEGIN
    DECLARE total DECIMAL(10, 2);
    
    SELECT 
        SUM((price + vat_amount) * quantity) INTO total
    FROM 
        Ordered_Item
    WHERE 
        order_id = order_id_pm;

    SELECT total AS order_total;
END //

DELIMITER ;