USE BuyPy;


INSERT INTO Client (firstname, surname, email, password, address, zip_code, city, country, phone_number, birthdate, is_active) VALUES
('John', 'Doe', 'john.doe@example.com', 'Passw0rd?', '123 Main St', 1234, 'Lisbon', 'Portugal', '123456789', '1980-01-01', 'active'),
('Jane', 'Smith', 'jane.smith@example.com', 'Passw0rd1?', '456 Elm St', 6789, 'Porto', 'Portugal', '234567890', '1990-02-02', 'active'),
('Alice', 'Johnson', 'alice.johnson@example.com', 'Passw0rd2?', '789 Maple St', 1011, 'Coimbra', 'Portugal', '345678901', '1985-03-03', 'active'),
('Bob', 'Brown', 'bob.brown@example.com', 'Passw0rd3?', '101 Oak St', 1314, 'Faro', 'Portugal', '456789012', '1975-04-04', 'active'),
('Carol', 'White', 'carol.white@example.com', 'Passw0rd4?', '102 Pine St', 1516, 'Braga', 'Portugal', '567890123', '1987-05-05', 'active'),
('Dave', 'Green', 'dave.green@example.com', 'Passw0rd5?', '103 Cedar St', 1718, 'Aveiro', 'Portugal', '678901234', '1992-06-06', 'active'),
('Eve', 'Black', 'eve.black@example.com', 'Passw0rd6?', '104 Birch St', 1920, 'Évora', 'Portugal', '789012345', '1983-07-07', 'active'),
('Frank', 'Gray', 'frank.gray@example.com', 'Passw0rd7?', '105 Spruce St', 2122, 'Viseu', 'Portugal', '890123456', '1995-08-08', 'active'),
('Grace', 'Red', 'grace.red@example.com', 'Passw0rd8?', '106 Walnut St', 2324, 'Leiria', 'Portugal', '901234567', '1978-09-09', 'active'),
('Hank', 'Blue', 'hank.blue@example.com', 'Passw0rd9?', '107 Cherry St', 2526, 'Guarda', 'Portugal', '012345678', '1986-10-10', 'active'),
('Ivy', 'Yellow', 'ivy.yellow@example.com', 'Passw0rd10?', '108 Ash St', 2728, 'Santarem', 'Portugal', '123456789', '1994-11-11', 'active'),
('Jack', 'Purple', 'jack.purple@example.com', 'Passw0rd11?', '109 Fir St', 2930, 'Setúbal', 'Portugal', '234567890', '1993-12-12', 'active'),
('Karen', 'Orange', 'karen.orange@example.com', 'Passw0rd12?', '110 Elm St', 3132, 'Beja', 'Portugal', '345678901', '1989-01-13', 'active'),
('Leo', 'Pink', 'leo.pink@example.com', 'Passw0rd13?', '111 Maple St', 3332, 'Portalegre', 'Portugal', '456789012', '1982-02-14', 'active'),
('Mia', 'Teal', 'mia.teal@example.com', 'Passw0rd14?', '112 Oak St', 3536, 'Viana do Castelo', 'Portugal', '567890123', '1991-03-15', 'active');


INSERT INTO Product (id, quantity, price, vat, score, product_image, is_active, reason) VALUES
('P001', 10, 19.99, 23.00, 5, 'image1.jpg', 'Active', 'Popular book'),
('P002', 5, 299.99, 23.00, 4, 'image2.jpg', 'Active', 'New arrival'),
('P003', 15, 15.99, 23.00, 3, 'image3.jpg', 'Active', 'Best seller'),
('P004', 7, 499.99, 23.00, 5, 'image4.jpg', 'Inactive', 'Limited stock'),
('P005', 20, 25.50, 23.00, 4, 'image5.jpg', 'Active', 'Top rated'),
('P006', 12, 399.99, 23.00, 3, 'image6.jpg', 'Active', 'High demand'),
('P007', 8, 12.75, 23.00, 2, 'image7.jpg', 'Inactive', 'Discounted'),
('P008', 9, 89.99, 23.00, 5, 'image8.jpg', 'Active', 'Trending'),
('P009', 13, 30.00, 23.00, 3, 'image9.jpg', 'Active', 'Recommended'),
('P010', 6, 279.99, 23.00, 4, 'image10.jpg', 'Inactive', 'New model'),
('P011', 11, 22.50, 23.00, 2, 'image11.jpg', 'Active', 'Clearance sale'),
('P012', 4, 699.99, 23.00, 5, 'image12.jpg', 'Active', 'Premium quality'),
('P013', 14, 18.99, 23.00, 3, 'image13.jpg', 'Inactive', 'Customer favorite'),
('P014', 3, 159.99, 23.00, 4, 'image14.jpg', 'Active', 'Best buy'),
('P015', 2, 10.00, 23.00, 1, 'image15.jpg', 'Active', 'Value for money');


INSERT INTO Book (product_id, ISBN, title, genre, publisher, publication_date) VALUES
('P001', '978-3-16-148410-0', 'Book Title 1', 'Fiction', 'Publisher A', '2020-01-01'),
('P002', '978-1-86197-876-9', 'Book Title 2', 'Non-Fiction', 'Publisher B', '2021-02-01'),
('P003', '978-0-14-044913-6', 'Book Title 3', 'Sci-Fi', 'Publisher C', '2019-03-01'),
('P004', '978-0-7432-7356-5', 'Book Title 4', 'Fantasy', 'Publisher D', '2018-04-01'),
('P005', '978-1-4028-9462-6', 'Book Title 5', 'Mystery', 'Publisher E', '2022-05-01'),
('P006', '978-0-525-47546-1', 'Book Title 6', 'Romance', 'Publisher F', '2017-06-01'),
('P007', '978-0-06-245771-4', 'Book Title 7', 'Thriller', 'Publisher G', '2023-07-01'),
('P008', '978-0-385-52895-6', 'Book Title 8', 'Horror', 'Publisher H', '2016-08-01'),
('P009', '978-1-250-08065-3', 'Book Title 9', 'Historical', 'Publisher I', '2015-09-01'),
('P010', '978-0-374-28018-3', 'Book Title 10', 'Biography', 'Publisher J', '2014-10-01');


INSERT INTO Electronic (product_id, serial_number, brand, model, spec_tec, product_type) VALUES
('P011', 123456789012345, 'Brand A', 'Model X', 'Specs 1', 'Type 1'),
('P012', 987654321098765, 'Brand B', 'Model Y', 'Specs 2', 'Type 2'),
('P013', 192837465091827, 'Brand C', 'Model Z', 'Specs 3', 'Type 3'),
('P014', 564738291045678, 'Brand D', 'Model W', 'Specs 4', 'Type 4'),
('P015', 283746591028374, 'Brand E', 'Model V', 'Specs 5', 'Type 5');


INSERT INTO `Order` (date_time, delivery_method, `status`, payment_card_number, payment_card_name, payment_card_expiration, client_id) VALUES
('2023-01-01 10:00:00', 'regular', 'open', 1234567890123456, 'John Doe', '2025-01-01', 1),
('2023-01-02 11:00:00', 'urgent', 'processing', 2345678901234567, 'Jane Smith', '2026-02-01', 2),
('2023-01-03 12:00:00', 'regular', 'pending', 3456789012345678, 'Alice Johnson', '2024-03-01', 3),
('2023-01-04 13:00:00', 'urgent', 'closed', 4567890123456789, 'Bob Brown', '2025-04-01', 4),
('2023-01-05 14:00:00', 'regular', 'cancelled', 5678901234567890, 'Carol White', '2026-05-01', 5),
('2023-01-06 15:00:00', 'urgent', 'open', 6789012345678901, 'Dave Green', '2027-06-01', 6),
('2023-01-07 16:00:00', 'regular', 'processing', 7890123456789012, 'Eve Black', '2028-07-01', 7),
('2023-01-08 17:00:00', 'urgent', 'pending', 8901234567890123, 'Frank Gray', '2029-08-01', 8),
('2023-01-09 18:00:00', 'regular', 'closed', 9012345678901234, 'Grace Red', '2030-09-01', 9),
('2023-01-10 19:00:00', 'urgent', 'cancelled', 1234567890123456, 'Hank Blue', '2031-10-01', 10),
('2023-01-11 20:00:00', 'regular', 'open', 2345678901234567, 'Ivy Yellow', '2032-11-01', 11),
('2023-01-12 21:00:00', 'urgent', 'processing', 3456789012345678, 'Jack Purple', '2033-12-01', 12),
('2023-01-13 22:00:00', 'regular', 'pending', 4567890123456789, 'Karen Orange', '2034-01-01', 13),
('2023-01-14 23:00:00', 'urgent', 'closed', 5678901234567890, 'Leo Pink', '2035-02-01', 14),
('2023-01-15 00:00:00', 'regular', 'cancelled', 6789012345678901, 'Mia Teal', '2036-03-01', 15);


INSERT INTO Ordered_Item (order_id, product_id, quantity, price, vat_amount) VALUES
(1, 'P001', 1, 19.99, 4.60),
(2, 'P002', 1, 299.99, 69.00),
(3, 'P003', 2, 15.99, 7.36),
(4, 'P004', 1, 499.99, 115.00),
(5, 'P005', 3, 25.50, 17.63),
(6, 'P006', 2, 399.99, 92.00),
(7, 'P007', 1, 12.75, 2.93),
(8, 'P008', 1, 89.99, 20.70),
(9, 'P009', 1, 30.00, 6.90),
(10, 'P010', 1, 279.99, 64.40),
(11, 'P011', 1, 22.50, 5.18),
(12, 'P012', 1, 699.99, 161.00),
(13, 'P013', 2, 18.99, 8.74),
(14, 'P014', 1, 159.99, 36.80),
(15, 'P015', 3, 10.00, 6.90);


INSERT INTO Recommendation (product_id, client_id, reason, start_date) VALUES
('P001', 1, 'Great book', '2024-05-01'),
('P002', 2, 'Highly recommended', '2024-05-02'),
('P003', 3, 'Must read', '2024-05-03'),
('P004', 4, 'Excellent quality', '2024-05-04'),
('P005', 5, 'Worth buying', '2024-05-05'),
('P006', 6, 'Top pick', '2024-05-06'),
('P007', 7, 'Amazing product', '2024-05-07'),
('P008', 8, 'Great value', '2024-05-08'),
('P009', 9, 'Editor\'s choice', '2024-05-09'),
('P010', 10, 'Best in class', '2024-05-10'),
('P011', 11, 'Customer favorite', '2024-05-11'),
('P012', 12, 'Highly rated', '2024-05-12'),
('P013', 13, 'Top seller', '2024-05-13'),
('P014', 14, 'Excellent reviews', '2024-05-14'),
('P015', 15, 'Great deal', '2024-05-15');


INSERT INTO Operator (firstname, surname, email, password) VALUES
('Admin', 'One', 'admin.one@example.com', 'Adm1nPass!'),
('Admin', 'Two', 'admin.two@example.com', 'Adm1nPass!'),
('Admin', 'Three', 'admin.three@example.com', 'Adm1nPass!'),
('Admin', 'Four', 'admin.four@example.com', 'Adm1nPass!'),
('Admin', 'Five', 'admin.five@example.com', 'Adm1nPass!'),
('Admin', 'Six', 'admin.six@example.com', 'Adm1nPass!'),
('Admin', 'Seven', 'admin.seven@example.com', 'Adm1nPass!'),
('Admin', 'Eight', 'admin.eight@example.com', 'Adm1nPass!'),
('Admin', 'Nine', 'admin.nine@example.com', 'Adm1nPass!'),
('Admin', 'Ten', 'admin.ten@example.com', 'Adm1nPass!'),
('Admin', 'Eleven', 'admin.eleven@example.com', 'Adm1nPass!'),
('Admin', 'Twelve', 'admin.twelve@example.com', 'Adm1nPass!'),
('Admin', 'Thirteen', 'admin.thirteen@example.com', 'Adm1nPass!'),
('Admin', 'Fourteen', 'admin.fourteen@example.com', 'Adm1nPass!'),
('Admin', 'Fifteen', 'admin.fifteen@example.com', 'Adm1nPass!');


INSERT INTO Author (`name`, fullname, birthdate) VALUES
('Author A', 'Full Name A', '1970-01-01'),
('Author B', 'Full Name B', '1980-02-02'),
('Author C', 'Full Name C', '1990-03-03'),
('Author D', 'Full Name D', '1960-04-04'),
('Author E', 'Full Name E', '1950-05-05'),
('Author F', 'Full Name F', '1940-06-06'),
('Author G', 'Full Name G', '1930-07-07'),
('Author H', 'Full Name H', '1920-08-08'),
('Author I', 'Full Name I', '1910-09-09'),
('Author J', 'Full Name J', '1900-10-10'),
('Author K', 'Full Name K', '2000-11-11'),
('Author L', 'Full Name L', '2010-12-12'),
('Author M', 'Full Name M', '2005-01-01'),
('Author N', 'Full Name N', '1995-02-02'),
('Author O', 'Full Name O', '1985-03-03');


INSERT INTO BookAuthor (product_id, author_id) VALUES
('P001', 1),
('P002', 2),
('P003', 3),
('P004', 4),
('P005', 5),
('P006', 6),
('P007', 7),
('P008', 8),
('P009', 9),
('P010', 10),
('P001', 11),
('P002', 12),
('P003', 13),
('P004', 14),
('P005', 15);