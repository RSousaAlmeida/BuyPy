
DROP DATABASE IF EXISTS BuyPy;

CREATE DATABASE BuyPy;

USE BuyPy;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS Recommendation;
DROP TABLE IF EXISTS Ordered_Item;
DROP TABLE IF EXISTS BookAuthor;
DROP TABLE IF EXISTS Author;
DROP TABLE IF EXISTS Electronic;
DROP TABLE IF EXISTS Book;
DROP TABLE IF EXISTS `Order`;
DROP TABLE IF EXISTS Operator;
DROP TABLE IF EXISTS `Client`;
DROP TABLE IF EXISTS Product;

CREATE TABLE Product (
    id VARCHAR(10) PRIMARY KEY,
    quantity INT NOT NULL CHECK (quantity > 0),
    price DECIMAL(10,2) NOT NULL CHECK (price > 0),
    vat DECIMAL(5, 2) NOT NULL CHECK (vat >= 0 AND vat <= 100),
    score TINYINT NOT NULL CHECK (score >= 1 AND score <= 5),
    product_image VARCHAR(255) NOT NULL,
    is_active ENUM('Active', 'Inactive'),
    reason VARCHAR(500)
);

CREATE TABLE Book (
    product_id VARCHAR(10),  
    ISBN VARCHAR(20) NOT NULL UNIQUE,
    title VARCHAR(50) NOT NULL,
    genre VARCHAR(50) NOT NULL,
    publisher VARCHAR(100) NOT NULL,
    publication_date DATE NOT NULL,
    FOREIGN KEY (product_id) REFERENCES Product(id)
);

CREATE TABLE Electronic (
    product_id VARCHAR(10),
    serial_number BIGINT NOT NULL UNIQUE,
    brand VARCHAR(20) NOT NULL,
    model VARCHAR(20) NOT NULL,
    spec_tec TEXT,
    product_type VARCHAR(10) NOT NULL,
    FOREIGN KEY (product_id) REFERENCES Product(id)
);

CREATE TABLE `Order` (
    id INT PRIMARY KEY AUTO_INCREMENT,
    date_time DATETIME DEFAULT NOW(),
    delivery_method VARCHAR(10) DEFAULT 'regular' CHECK (delivery_method IN('regular', 'urgent')),
    `status` VARCHAR(10) DEFAULT 'open' CHECK (`status` IN ('open', 'processing', 'pending', 'closed', 'cancelled')),
    payment_card_number BIGINT NOT NULL,
    payment_card_name VARCHAR(20) NOT NULL,
    payment_card_expiration DATE NOT NULL,
    client_id INT,
    FOREIGN KEY (client_id) REFERENCES `Client`(id)
);

CREATE TABLE Client (
    id INT PRIMARY KEY AUTO_INCREMENT,
    firstname VARCHAR(250) NOT NULL,
    surname VARCHAR(250) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
	`password` CHAR(64) NOT NULL, 
    address VARCHAR(100) NOT NULL,
    zip_code SMALLINT UNSIGNED NOT NULL, 
    city VARCHAR(30) NOT NULL,
    country VARCHAR(30) DEFAULT 'Portugal',
    phone_number VARCHAR(15), 
    last_login TIMESTAMP NOT NULL DEFAULT (NOW()),
    birthdate DATE NOT NULL,
    is_active ENUM('active', 'blocked') NOT NULL,
    CONSTRAINT PhoneNumberCHK CHECK (phone_number REGEXP '^[0-9]{6,}$'),
    CONSTRAINT EmailCHK CHECK (email REGEXP '[a-z0-9!#$%&\'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&\'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$'),
    CONSTRAINT CheckPassword CHECK (
        LENGTH(password) >= 6
        AND password REGEXP '[0-9]'
        AND password REGEXP '[a-z]'
        AND password REGEXP '[A-Z]'
        AND password REGEXP '[!$#?%]'
    ),
    CONSTRAINT CheckPasswordLength CHECK (LENGTH(password) <= 50)
);

CREATE TABLE Ordered_Item (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id VARCHAR(10),
    quantity INT NOT NULL CHECK(quantity > 0),
    price DECIMAL(10,2) NOT NULL CHECK(price > 0),
    vat_amount DECIMAL(10,2) NOT NULL CHECK(vat_amount > 0),
    FOREIGN KEY (order_id) REFERENCES `Order`(id),
    FOREIGN KEY (product_id) REFERENCES Product(id)
);

CREATE TABLE Recommendation (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id VARCHAR(10),
    client_id INT,
    reason VARCHAR(500),
    start_date DATE,
    FOREIGN KEY (client_id) REFERENCES Client(id),
    FOREIGN KEY (product_id) REFERENCES Product(id)
);

CREATE TABLE Operator (
    id INT PRIMARY KEY AUTO_INCREMENT,
    firstname VARCHAR(250),
    surname VARCHAR(250),
    email VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(50) NOT NULL,  
    CONSTRAINT OperatorEmailCHK CHECK (email REGEXP '[a-z0-9!#$%&\'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&\'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$'),
    CONSTRAINT OperatorCheckPassword CHECK (
        LENGTH(password) >= 6
        AND password REGEXP '[0-9]'
        AND password REGEXP '[a-z]'
        AND password REGEXP '[A-Z]'
        AND password REGEXP '[!$#?%]'
    ),
    CONSTRAINT OperatorCheckPasswordLength CHECK (LENGTH(password) <= 50)
);

CREATE TABLE Author (
    id INT PRIMARY KEY AUTO_INCREMENT,
    `name` VARCHAR(100),
    fullname VARCHAR(100),
    birthdate DATE NOT NULL
);

CREATE TABLE BookAuthor (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id VARCHAR(10),
    author_id INT,
    FOREIGN KEY (author_id) REFERENCES Author(id),
    FOREIGN KEY (product_id) REFERENCES Product(id)
);

ALTER TABLE Author
    MODIFY COLUMN `name` VARCHAR(100) COMMENT "Author's literary/pseudo name, for which he is known",
    MODIFY COLUMN fullname VARCHAR(100) COMMENT "Author's real full name";

SET foreign_key_checks = 1;

#call GetOrderTotal(6);
#call AnnualOrders(1, 2023);
#call ProductByType(NULL);